import React from 'react';
import Chatbox from './Chatbox'; // Import the Chatbox component

function ChatboxPopup({ isOpen, onClose }) {
    const handleClickInside = (event) => {
        event.stopPropagation(); // Prevent the click event from bubbling up
    };

    return (
        <div className={`chatbox-popup ${isOpen ? 'open' : ''}`} onClick={onClose}>
            <div className="chatbox-popup__content" onClick={handleClickInside}>
                <Chatbox /> {/* Render the Chatbox component */}
            </div>
        </div>
    );
}

export default ChatboxPopup;
