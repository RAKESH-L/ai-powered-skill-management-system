import React, { useState } from 'react';
import ChatboxPopup from './ChatboxPopup';

function ChatboxButton() {
    const [isOpen, setIsOpen] = useState(false);

    const togglePopup = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div className="chatbox__button">
            <button onClick={togglePopup}>
                <img src={require('./images/hello.svg').default} alt="hello icon" />
            </button>
            {isOpen && <ChatboxPopup isOpen={isOpen} onClose={() => setIsOpen(false)} />}
        </div>
    );
}

export default ChatboxButton;
