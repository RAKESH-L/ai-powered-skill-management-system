import React, { useState } from 'react';
import './css/Chatbot.css';
import './images/hello.svg';
import muteSound from './sounds/mute2.wav'; // Import the sound file
import sendSound from './sounds/mute.wav'; // Import the sound file

function Chatbox() {
    const [messages, setMessages] = useState([]);
    const [messageInput, setMessageInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [isListening, setIsListening] = useState(false); // State to track speech recognition status

    const handleMessageChange = (event) => {
        setMessageInput(event.target.value);
    };
    const handleSendMessageAndPlaySound = () => {
    handleSendMessage();
    playSendSound();
};
    const handleVoiceMessageAndPlaySound = () => {
    handleVoice();
    playMuteSound();
};

    const handleEnterPress = (event) => {
        if (event.key === 'Enter') {
            handleSendMessage();
        }
    };
        const playMuteSound = () => {
        const audio = new Audio(muteSound);
        audio.play();
    };
      const playSendSound = () => {
        const audio = new Audio(sendSound);
        audio.play();
    };

    const handleVoice = async () => {
        try {
            const recognition = new window.webkitSpeechRecognition();
            recognition.lang = 'en-US';
            recognition.onstart = () => {
                setIsListening(true); // Set isListening to true when speech recognition starts
            };
            recognition.onend = () => {
                setIsListening(false); // Set isListening to false when speech recognition ends
            };
            recognition.onresult = (event) => {
                const voiceInput = event.results[0][0].transcript;
                setMessageInput(voiceInput);
                handleSendMessage();
            };
            recognition.start();
        } catch (error) {
            console.error('Error starting speech recognition:', error);
        }
    };

    const handleSendMessage = () => {
        if (messageInput.trim() === '') return;

        const newUserMessage = { role: 'user', text: messageInput };
        setMessages([...messages, newUserMessage]);
        setMessageInput('');
        setIsTyping(true);

        fetch('http://127.0.0.1:5000/chat', {
            method: 'POST',
            body: JSON.stringify({ text: messageInput }),
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json'
            },
        })
        .then(response => response.json())
        .then(data => {
            setIsTyping(false);
            if (Array.isArray(data) && data.length > 0) {
                const regex = /value=[\"\']([^\"\']*)[\"\']/;
                const match = regex.exec(data[0].content);
                const textContent = match ? match[1] : null;

                if (textContent) {
                    const botResponseMessage = { role: 'bot', text: textContent };
                    setMessages((prevMessages) => [...prevMessages, botResponseMessage]);
                    speak(textContent);
                } else {
                    console.error('Unable to extract text content:', data[0].content);
                }
            } else {
                console.error('Invalid response format:', data);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    };

    const speak = (text) => {
        const voiceses = speechSynthesis.getVoices();
        if (voiceses.length === 0) {
            speechSynthesis.onvoiceschanged = () => {
                const voice = speechSynthesis.getVoices().find(voice => voice.name === 'Microsoft Luna Online (Natural) - English (Singapore)');
                const speech = new SpeechSynthesisUtterance(text);
                speech.voice = voice;
                speech.rate = 1.2;
                speech.pitch = 45;
                window.speechSynthesis.speak(speech);
                speechSynthesis.onvoiceschanged = null;
            };
        } else {
            const voice = voiceses.find(voice => voice.name === 'Microsoft Luna Online (Natural) - English (Singapore)');
            const speech = new SpeechSynthesisUtterance(text);
            speech.voice = voice;
            speech.rate = 1.2;
            speech.pitch = 45;
            window.speechSynthesis.speak(speech);
        }
    };

    return (
        <div className="container">
            <div className="chatbox">
                <div className="chatbox__support">
                    <div className="chatbox__header">
                        <div className="chatbox__image--header">
                            <img src="https://img.icons8.com/color/48/000000/circled-user-female-skin-type-5--v1.png" alt="User" />
                        </div>
                        <div className="chatbox__content--header">
                            <h4 className="chatbox__heading--header">Skill Management</h4>
                            <p className="chatbox__description--header">Hi. My name is Skilly. I am here to collect your skills?</p>
                        </div>
                    </div>
                    <div className="chatbox__messages">
                        {messages.slice().reverse().map((msg, index) => (
                            <div key={index} className={`messages__item ${msg.role === 'bot' ? 'messages__item--visitor' : 'messages__item--operator'}`}>
                                {msg.text}
                            </div>
                        ))}
                    </div>
                    {isTyping && <div className="messages__item messages__item--typing">Typing...</div>}
                    {isListening && <div className="messages__item messages__item--typing">Listening...</div>} {/* Display listening status */}
                    <div className="chatbox__footer">
                        <button 
                            className='chatbox__send--footer send__button' 
                             onClick={handleVoiceMessageAndPlaySound}
                            style={{ 
                                border: 'none', 
                                background: 'none', 
                                padding: '8px',
                                marginRight: '5px', 
                                cursor: 'pointer',
                                boxShadow: '0px 10px 15px rgba(0, 0, 0, 0.1)', // Box shadow
                                transition: 'background 0.3s ease',
                                borderRadius: '50px', // Rounded border
                            }}
                        >
                            <img src={require('./images/mute.svg').default} alt="hero icon" width="24" height="24" />
                        </button>
                        <input
                            type="text"
                            value={messageInput}
                            onChange={handleMessageChange}
                            onKeyPress={handleEnterPress} 
                            placeholder="Write a message..."
                        />
                        <button 
                            className='chatbox__send--footer send__button'
                            onClick={handleSendMessageAndPlaySound}
                            style={{ 
                                border: 'none', 
                                background: 'none', 
                                padding: '8px', 
                                cursor: 'pointer',
                                boxShadow: '0px 10px 15px rgba(0, 0, 0, 0.1)', // Box shadow
                                marginLeft: '5px',
                                transition: 'background 0.3s ease',
                                borderRadius: '50px', // Rounded border
                            }}
                        >
                            <img src={require('./images/hero.svg').default} alt="hero icon" width="24" height="24" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Chatbox;













