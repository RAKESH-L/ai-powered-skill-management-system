import React, { useState } from 'react';

function ChatBot() {
  const [userInput, setUserInput] = useState('');
  const [messages, setMessages] = useState([]);

  const handleUserInput = (event) => {
    setUserInput(event.target.value);
  };

const sendMessage = () => {
  if (!userInput.trim()) return;

  setMessages((prevMessages) => [...prevMessages, { role: 'user', text: userInput }]);
  setUserInput('');

  fetch('http://127.0.0.1:5000/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text: userInput }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then((data) => {
  console.log("Data:", data); // Log the entire data object

  // Parse the string containing TextContentBlock information
  const textContentBlockString = data.text;
  const regex = /value='(.*?)'/;
  const match = regex.exec(textContentBlockString);
  const value = match ? match[1] : null;

  if (value) {
    console.log("Data.text:", value); // Log the extracted value
    setMessages((prevMessages) => [...prevMessages, { role: 'bot', text: value }]);
  } else {
    console.error('Invalid response format:', data);
  }
})

};


  return (
    <div>
      <div className="chat-window">
        {messages.map((message, index) => (
          <div key={index} className={message.role}>
            {message.text}
          </div>
        ))}
      </div>
      <div className="input-box">
        <input type="text" value={userInput} onChange={handleUserInput} />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
}

export default ChatBot;
